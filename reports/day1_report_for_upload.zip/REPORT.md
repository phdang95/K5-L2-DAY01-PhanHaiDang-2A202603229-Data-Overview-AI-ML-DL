# Báo cáo bài thực hành Ngày 1 – Đọc prediction YOLO11 để hiểu định dạng nhãn

**Ngày chạy:**06/11/2026

**Runtime Colab:** CPU/GPU

**Python / PyTorch / Ultralytics:**

**Checkpoint:** `yolo11n-cls.pt`, `yolo11n.pt`, `yolo11n-seg.pt`

**Ngưỡng detection/segmentation dùng khi tạo JSON:** `0.35` (chỉ đổi nếu GV cho phép; nếu đổi hãy ghi rõ)

**Thay đổi so với notebook nguồn:** Không / mô tả rõ thay đổi

> **Cách dùng mẫu này:** copy/điền trên máy, lưu thành `REPORT.md`, rồi **upload** vào panel Files
> của Colab (notebook không tự tạo file này). Ô cuối Colab sẽ đóng ZIP cùng `day1_lab_outputs/`.
> Giải nén và đưa vào `report/` trên GitHub, rồi nộp **link repo** trên LMS.
> Không ghi họ tên, MSSV, email, số điện thoại hoặc dữ liệu cá nhân khác vào báo cáo/output;
> họ tên/MSSV chỉ nằm trong tên repository.

### Từ cần nhớ (đọc nhanh trước khi viết)

| Từ | Nghĩa ngắn |
| --- | --- |
| Prediction | Kết quả model vừa đoán ra; chưa phải nhãn đúng |
| Ground truth | Nhãn do người gán theo quy tắc |
| Taxonomy | Danh sách tên lớp có sẵn kèm model (vd. ImageNet-1K, COCO-80) |
| Checkpoint | File model `.pt` đã huấn luyện sẵn |
| Guideline | Quy tắc gán nhãn do người viết |
| Annotator | Người gán nhãn |
| Reviewer / QC | Người kiểm tra nhãn |
| Escalation | Ca khó → hỏi Lab Coach, không tự bịa |
| Model score | Số “tin” của model; không phải điểm chất lượng nhãn người |

## 1. Phân loại ảnh

**Mở file:** `day1_lab_outputs/classification_predictions.json` và `visuals/classification_top5.png`.  
Chỉ dùng ảnh `sample_id = traffic`, lấy dòng `rank = 1`.

1. Chép record hạng 1: `class_id`=468 ; `class_name`=cab ; `rank`=1 ; `score`=510915 ; `taxonomy_name`=ImageNet-1K
2. Record này nói về **cả bức ảnh** hay về **một vật thể riêng** trong ảnh? Vì sao bạn nghĩ vậy? Trả lời: Cả bức ảnh vì có vẻ phần kết quả nói đến mật độ phân bổ vật thể trong ảnh
3. Danh sách tên lớp (class list) do đâu mà có: model tự nghĩ ra, hay đi kèm taxonomy/checkpoint? Trả lời: Model quyết định, phần code có names = result.names
4. Vì sao cần ghi cả `class_id`, `class_name` và `taxonomy_name`, không chỉ ghi mỗi tên lớp?
Trả lời: +, taxonomy_name: Xác định tập nhãn chuẩn, tránh nhầm lẫn giữa các bộ dữ liệu khác nhau. 
         +, class_id: Mã hóa số nguyên chuẩn cho thuật toán, tránh lỗi sai lệch chuỗi ký tự. 
         +, class_name: Người đọc hiểu trực tiếp mà không cần tra cứu bảng ánh xạ.
Các model có thể chạy tốt với các số nguyên, sử dụng string sẽ khó khăn, và tránh nhầm với human input, còn con người thích nhìn name đỡ phải tra lại bảng quy tắc nên sẽ cần các bộ id đi cùng nhau
5. Nếu trong ảnh có nhiều vật / nhiều chủ đề, guideline cần nói rõ điều gì để người gán nhãn chọn **một** lớp?
Trả lời: Guideline cần quy định rõ nguyên tắc chọn một lớp duy nhất:

        +,Ưu tiên chủ thể chiếm diện tích lớn nhất (salient object).
        +,Ưu tiên vật thể nằm ở vị trí trung tâm bức ảnh.
        +,Đặt bảng thứ tự ưu tiên khi có tranh chấp (ví dụ: người > phương tiện > nền).
6. Vì sao không được lấy `score` của model làm ground truth?
Trả lời: vì có thể score chưa được kiểm chứng, chưa được verify theo quy tắc đặt ra, hoặc có thể vi phạm 1 số nguyên tắc nào đó.

## 2. Phát hiện vật thể

**Mở file:** `day1_lab_outputs/detection_predictions.json` và `visuals/detection_predictions.png`.  
Chỉ dùng ảnh `sample_id = kitchen`. Chọn **một** record.  
Số lượng prediction theo ngưỡng: xem output ô so sánh `0.20` / `0.35` / `0.60` trong notebook.

1. Chép một record: `class_name`=person ; `score`=0.912625 ; `bbox_xyxy`=[385.33, 69.24, 498.92, 348.92] ; `bbox_width`=113.58 ; `bbox_height`=279.68
2. Giải thích box bằng lời thường: góc trên-trái ở đâu, góc dưới-phải ở đâu, rộng/cao bao nhiêu pixel?
Trả lời: góc trên- trái: x_min,y_min: [385.33,69.24], góc dưới-phải: x_max,y_max: [498.92,348.92], rộng: 113.58, cao: 279.68
3. Chọn hai ngưỡng (vd. 0.20 và 0.60). Mỗi ngưỡng có bao nhiêu prediction?
Trả lời: Ngưỡng 0.20: 11 prediction (toàn bộ prediction của kitchen đều có score ≥ ≥0.38).
         Ngưỡng 0.60: 6 prediction (gồm 2 person, 2 bowl, 2 oven).
4. Khi hạ ngưỡng (giữ nhiều hộp hơn), người **reviewer** phải làm thêm việc gì?
Trả lời: Reviewer phải:
                       +,Xóa các box dự đoán sai (false positives / nhiễu / rác).
                       +,Lọc/xóa các box trùng lặp (duplicate boxes trên cùng 1 vật thể).
                       +,Nắn chỉnh lại viền các box bị lệch tọa độ.
5. Viết **một quy tắc box** để người gán nhãn làm theo (áp dụng được cho nhiều ảnh, không chỉ ảnh này).
Trả lời: có thể thêm quy tắc vẽ viền bao quanh khít mép ngoài cùng phần nhìn thấy được của vật thể nhất có thể; không chừa viền nền thừa, không cắt lẹm vào vật thể.
6. Trên ảnh `kitchen`, chỉ ra **một** vật bị che khuất hoặc cắt mép. Bạn sẽ viết thành quy tắc trong guideline, hay đưa lên hỏi Lab Coach (escalation)? Vì sao?
Trả lời: Oven bên trái [0.11, 187.54, 195.96, 292.81] bị cắt mép ảnh bên trái. Tôi sẽ viết thành quy tắc trong guideline vì phần này sẽ gặp nhiều trong bài toán dạng này không nhất thiết phải escalation.

## 3. Phân đoạn theo từng đối tượng

**Mở file:** `day1_lab_outputs/segmentation_predictions.json` và `visuals/segmentation_prediction.png`.  
Chỉ dùng ảnh `sample_id = kitchen`. Chọn **một** record.

1. Chép một record: `instance_id`=kitchen-001 ; `class_name`=person ; `score`=0.899318 ; số điểm polygon=`polygon_point_count`=348 ; 3–5 điểm đầu của `polygon_xy`= [[446.0, 70.0], [445.0, 71.0], [444.0, 71.0], [443.0, 72.0], [442.0, 72.0]]
2. So với box, polygon cho thêm thông tin gì về hình dạng vật thể?
Trả lời: +, Biên dạng thực tế: Cung cấp đường bao chi tiết đến từng pixel thay vì hộp chữ nhật thô.
         +, Loại bỏ nền: Lọc sạch điểm ảnh nền lọt vào trong box (ví dụ: khoảng trống giữa hai chân người).
         +,Hình dạng phức tạp: Thể hiện chính xác hình dạng lõm, uốn lượn, diện tích thực và góc nghiêng của vật thể.
3. `instance_id` dùng để làm gì? Nó **không** phải class ID và **không** phải tracking ID — bạn hiểu câu này thế nào?
Trả lời: Mục đích: Phân biệt các cá thể riêng lẻ cùng hoặc khác class hay track trong một bức ảnh.
4. Viết **một quy tắc vẽ biên mask** để người gán nhãn làm theo.
Trả lời: Quy tắc biên bám sát và loại bỏ che khuất: Đặt điểm polygon áp sát đường ranh giới nhìn thấy của vật . Không viền qua điểm ảnh nền hoặc phần bị vật thể khác che đè lên.
5. Trên ảnh `kitchen`, chỉ ra **một** chỗ biên mờ / hai vật chạm nhau / bị che. Bạn dùng guideline hay escalation? Vì sao?
Trả lời: Vị trí: Hai chiếc bát chạm và đè mép lên nhau ở góc trái mặt bàn (bowl 0.74 đè một phần lên bowl 0.53), cùng tiếp xúc đè lên dining table.
Cách xử lý: Dùng Guideline. Vì: Che khuất và chạm nhau là trường hợp chuẩn, gặp thường xuyên trong dán nhãn nội thất. Guideline luôn có sẵn quy tắc ưu tiên vật nằm trên (foreground) và chỉ vẽ phần nhìn thấy được (visible mask). Chỉ dùng Escalation khi ảnh quá tối/vỡ nét, không thể phân biệt ranh giới và guideline chưa có quy định.
## 4. Vòng đời và kiểm tra chất lượng

Lab hôm nay chỉ **xem prediction**. Chuỗi dưới đây là vòng đời production để bạn nối các khái niệm:

`ảnh thô → guideline → ground truth → huấn luyện → prediction → QC/rework`

Điền bảng (viết ngắn, có dẫn chứng từ JSON/PNG khi nói về lỗi):

| Tác vụ | Ground truth trông như thế nào? (đơn vị nhãn) | Lỗi hoặc chỗ khó quyết định bạn thấy trên ảnh/JSON | Annotator làm gì? | Reviewer xem gì? |
| --- | --- | --- | --- | --- |
| Phân loại ảnh |1 nhãn danh mục duy nhất cho toàn bộ ảnh (bao gồm các bộ id duy nhất cho các nhóm đối tượng)  |Sai lệch tác vụ (Task mismatch) - Ảnh có quá nhiều xe: Bối cảnh kẹt xe chứa cùng lúc cả xe buýt lớn, xe taxi (cab), xe van (minibus). Không có một vật thể nào độc chiếm bức ảnh, khiến điểm số Top-1 cab chỉ đạt 51% và bị xé lẻ cho các loại xe khác. Gán 1 nhãn sẽ bỏ sót toàn bộ các xe còn lại.  | CEscalation: Báo cáo ảnh vi phạm cấu trúc đơn nhãn; đề xuất chuyển sang Multi-label (gán cùng lúc cả bus, cab, minibus) hoặc chuyển sang Object Detection. | Kiểm tra nhãn có bao quát đúng bối cảnh không; phạt lỗi chọn nhãn theo tiểu tiết (chảo treo) thay vì toàn cảnh. |
| Phát hiện vật thể | Danh sách các hộp chữ nhật [x_min, y_min, x_max, y_max] kèm class_id. | Lỗi nhầm nhãn do thiếu taxonomy: Đĩa nướng tròn bị ép thành bowl 0.38 vì COCO không có nhãn plate. | kéo box ôm khít đối tượng; tra bảng quy đổi khi vật không có class riêng (đĩa gán nhãn gì). | Soi độ khít box; kiểm tra loại bỏ các chi cắt cụt vi phạm guideline; kiểm tra tính nhất quán khi gán nhãn cho đĩa/bát. |
| Instance segmentation | Danh sách tọa độ đa giác polygon_xy (hoặc pixel mask) kèm instance_id và class_id. |Biên đè lấn và gán sai bản chất: Ảnh segmentation_prediction.png gán nhầm chùm thảo mộc khô treo thành potted plant 0.63 (kitchen-004); mask của dining table 0.58 bị khoét lởm chởm chỗ các bowl đè lên.  |Chấm điểm polygon viền sát mép pixel nhìn thấy (visible mask); tách riêng ranh giới từng vật chạm/đè nhau.  | Phóng to kiểm tra đường biên polygon (không ăn lẹm vào nền, không cắt cụt vật); kiểm tra xử lý đúng quy tắc chồng lấn giữa các vật. |

## 5. An toàn dữ liệu

1. Quy tắc bảo vệ dữ liệu của bạn cho bài lab này là gì? (viết 1 câu)
Không có họ tên, MSSV hoặc dữ liệu nhạy cảm trong báo cáo/output
2. Nếu gặp ảnh hoặc dữ liệu không đúng phạm vi, bạn sẽ dừng và báo cho ai?
Lab Coach 

## 6. Checklist trước khi nộp link repo

Kiểm tra trên GitHub trong thư mục `report/`:

- [ ] `REPORT.md` (file này đã điền)
- [ ] `day1_lab_outputs/classification_predictions.json`
- [ ] `day1_lab_outputs/detection_predictions.json`
- [ ] `day1_lab_outputs/segmentation_predictions.json`
- [ ] `day1_lab_outputs/IMAGE_ATTRIBUTION.md`
- [ ] `day1_lab_outputs/visuals/classification_top5.png`
- [ ] `day1_lab_outputs/visuals/detection_predictions.png`
- [ ] `day1_lab_outputs/visuals/segmentation_prediction.png`
- [ ] Ô validation cuối notebook báo `PASS`
- [ ] Không có họ tên, MSSV hoặc dữ liệu nhạy cảm trong báo cáo/output
- [ ] Đã nộp **link repository** trên LMS
